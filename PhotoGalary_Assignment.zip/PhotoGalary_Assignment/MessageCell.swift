//
//  MessageCell.swift
//  PhotoGalary_Assignment
//
//  Created by sumo on 09/05/18.
//  Copyright © 2018 sumo. All rights reserved.
//


import UIKit

class MessageCell: UICollectionViewCell {
  @IBOutlet weak var messageLabel: UILabel!
}
